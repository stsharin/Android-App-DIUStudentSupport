package com.example.diustudentsupport;

import androidx.fragment.app.Fragment;

public class CourseFragment extends Fragment {
}
